({
  name: 'main',
  mainConfigFile: 'main.js',
  out: 'bundle.js',
  optimize: 'none'
})
