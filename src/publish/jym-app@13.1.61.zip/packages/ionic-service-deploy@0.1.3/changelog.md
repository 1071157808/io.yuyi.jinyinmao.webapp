Changelog
=========

## 0.1.2

* Updated core dependency version


## 0.1.2

* Settings now pulled from $ionicCoreSettings


## 0.1.1

* Added info method. Fixes driftyco/ionic-plugins-deploy#11
