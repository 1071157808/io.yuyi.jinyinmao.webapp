---
name: floatingLabel
component: itemFloatingLabel
---

var app = angular.module('floatingLabel', ['ionic']);

app.controller('AppCtrl', function($scope) {

  $scope.favSong = "Tubthumping";

});
